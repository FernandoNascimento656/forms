
<?php

/**
 Guilherme Linhares / Motta - ServiceDeskBrasil

 */

class PluginFormcreatorUpgradeTo2_12_1_1
{

    protected $migration;

    /**
     * @param Migration $migration
     */
    public function upgrade(Migration $migration)
    {
        $this->migration = $migration;

        // Forms
        $tableForms = PluginFormcreatorForm::getTable();
        $tableQuestions = PluginFormcreatorQuestion::getTable();;
        $tableCategories = PluginFormcreatorCategory::getTable();;

        // Forms
        $migration->addField(
            $tableForms,
            'annotation',
            'string',
            [
                'value'   => null,
                'after'   => 'uuid',
                'comment' => 'Annotation to forms, never display in in Wizard'
            ]
        );

        $migration->addField(
            $tableForms,
            'url_image',
            'string',
            [
                'value'   => null,
                'after'   => 'annotation',
                'comment' => 'Display image'
            ]
        );

        // Migration da versão antiga:
        // - is_image_active -> forms -> is_display
        if (!$migration->changeField($tableForms, 'is_image_active', 'is_display', 'bool')) {
            $migration->addField(
                $tableForms,
                'is_display',
                'bool',
                [
                    'value'   => null,
                    'after'   => 'url_image',
                    'comment' => 'Annotation to forms, never display in in Wizard'
                ]
            );
        }

        // Questions
        $migration->addField(
            $tableQuestions,
            'annotation',
            'string',
            [
                'value'   => null,
                'after'   => 'uuid',
                'comment' => 'Annotation to question, never display in in Wizard'
            ]
        );

        // Categories
        $migration->addField(
            $tableCategories,
            'url_image',
            'string',
            [
                'value'   => null,
                'after'   => 'knowbaseitemcategories_id',
                'comment' => 'URL to display image'
            ]
        );

        // Migration da versão antiga:
        // - is_icone_active -> categoria -> is_display
        if (!$migration->changeField($tableCategories, 'is_icone_active', 'is_display', 'bool')) {
            $migration->addField(
                $tableCategories,
                'is_display',
                'bool',
                [
                    'value'   => null,
                    'after'   => 'url_image',
                    'comment' => 'Display image'
                ]
            );
        }
    }
}
